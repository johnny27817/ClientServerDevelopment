from pymongo import MongoClient
from bson.objectid import ObjectId
class AnimalShelter(object):
    
    def __init__(self, username, password):
            # Initializing the MongoClient. This helps to 
            # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:47353' % (username, password))
        self.database = self.client['AAC']
    
    # Complete this create method to implement the C in CRUD.
    def create(self, data):
        # Make sure data is not empty
        if data is not None:
            self.database.animals.insert_one(data)  # data should be dictionary 
            return True
            #If data is empty inform user
        else:
            return False
                
        def read_all(self,data):
            cursor = self.database.animals.find(data, {'_id':False})
            
            return cursor
                
        def read(self, data):
            
            return self.database.animals.find_one(data)
    
    # Create method to implement the R in CRUD. 
    def read(self, search):
        if search is not None:
            if search:
                found = self.database.animals.find(search)
        else:                                
            exception =  "Search is empty"                               
            return exception
      
    # Create method to implement the U in CRUD 
    def update(self, store):
        #Update document with match id otherwise store as new document within collection
        if store is not None:
            if store:
                
                storeResult = self.database.animals.insert_one(store)
                
            return storeResult
        else:
            raise Exception("Nothing to update store is empty")
            
    # Create method to implement the D in CRUD
    def delete(self, remove):
        if remove is not None:
            if remove:
                dataDelete = self.database.animals.delete_one(remove)
            else:
                raise Exception("Nothing to delete data  empty")